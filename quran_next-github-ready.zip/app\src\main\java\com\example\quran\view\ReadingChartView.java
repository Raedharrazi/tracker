package com.example.quran.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.quran.data.DailyTotal;

import java.util.ArrayList;
import java.util.List;

public class ReadingChartView extends View {

    private final Paint axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pointPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private List<DailyTotal> data = new ArrayList<>();

    public ReadingChartView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        axisPaint.setStrokeWidth(4f);

        linePaint.setStrokeWidth(6f);
        linePaint.setStyle(Paint.Style.STROKE);

        pointPaint.setStyle(Paint.Style.FILL);

        textPaint.setTextSize(32f);
    }

    public void setData(List<DailyTotal> data) {
        this.data = data == null ? new ArrayList<>() : data;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int w = getWidth();
        int h = getHeight();

        int left = 70;
        int top = 40;
        int right = 30;
        int bottom = 60;

        canvas.drawLine(left, top, left, h - bottom, axisPaint);
        canvas.drawLine(left, h - bottom, w - right, h - bottom, axisPaint);

        if (data.isEmpty()) {
            canvas.drawText("No reading yet", left, top + 40, textPaint);
            return;
        }

        int max = 1;
        for (DailyTotal d : data) {
            if (d.total > max) max = d.total;
        }

        float plotWidth = w - left - right;
        float plotHeight = h - top - bottom;

        float prevX = 0;
        float prevY = 0;

        for (int i = 0; i < data.size(); i++) {
            DailyTotal d = data.get(i);

            float x;
            if (data.size() == 1) {
                x = left + plotWidth / 2f;
            } else {
                x = left + (plotWidth * i / (data.size() - 1f));
            }

            float y = top + plotHeight - (plotHeight * d.total / (float) max);

            if (i > 0) {
                canvas.drawLine(prevX, prevY, x, y, linePaint);
            }

            canvas.drawCircle(x, y, 10f, pointPaint);

            String label = d.day;
            if (label != null && label.length() >= 10) {
                label = label.substring(5); // MM-dd
            }
            canvas.drawText(label == null ? "" : label, x - 24, h - 20, textPaint);

            prevX = x;
            prevY = y;
        }
    }
}