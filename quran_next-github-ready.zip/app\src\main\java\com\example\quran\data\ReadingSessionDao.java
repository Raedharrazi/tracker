package com.example.quran.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ReadingSessionDao {

    @Insert
    void insert(ReadingSession session);

    @Query("SELECT COALESCE(SUM(readCount), 0) FROM reading_sessions WHERE day = :day AND surahName = :surahName")
    int getTotalForDayAndSurah(String day, String surahName);

    @Query("SELECT day, COALESCE(SUM(readCount), 0) AS total " +
            "FROM reading_sessions " +
            "WHERE surahName = :surahName " +
            "GROUP BY day ORDER BY day ASC")
    List<DailyTotal> getDailyTotalsForSurah(String surahName);
}