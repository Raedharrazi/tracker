package com.example.quran.data;

public class Surah {
    public final int id;
    public final String name;
    public final int ayatCount;

    public Surah(int id, String name, int ayatCount) {
        this.id = id;
        this.name = name;
        this.ayatCount = ayatCount;
    }

    @Override
    public String toString() {
        return id + ". " + name + " (" + ayatCount + ")";
    }
}
