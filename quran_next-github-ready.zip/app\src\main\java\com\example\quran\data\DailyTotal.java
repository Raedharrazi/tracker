package com.example.quran.data;

public class DailyTotal {
    public String day;
    public int total;

    public DailyTotal(String day, int total) {
        this.day = day;
        this.total = total;
    }
}