package com.example.quran.notify;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ReminderScheduler {

    private static final String PREFS = "quran_tracker_prefs";
    private static final String KEY_HOUR = "reminder_hour";
    private static final String KEY_MINUTE = "reminder_minute";
    private static final String KEY_SURAH = "reminder_surah";

    private ReminderScheduler() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void saveReminder(Context context, int hour, int minute, String surahName) {
        prefs(context).edit()
                .putInt(KEY_HOUR, hour)
                .putInt(KEY_MINUTE, minute)
                .putString(KEY_SURAH, surahName)
                .apply();
    }

    public static void updateSurah(Context context, String surahName) {
        prefs(context).edit().putString(KEY_SURAH, surahName).apply();
    }

    public static boolean hasReminder(Context context) {
        SharedPreferences p = prefs(context);
        return p.contains(KEY_HOUR) && p.contains(KEY_MINUTE);
    }

    public static int getReminderHour(Context context) {
        return prefs(context).getInt(KEY_HOUR, 20);
    }

    public static int getReminderMinute(Context context) {
        return prefs(context).getInt(KEY_MINUTE, 0);
    }

    public static String getReminderSurah(Context context) {
        return prefs(context).getString(KEY_SURAH, "Al-Fatiha");
    }

    public static String getReminderLabel(Context context) {
        if (!hasReminder(context)) {
            return "No reminder set";
        }
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, getReminderHour(context));
        c.set(Calendar.MINUTE, getReminderMinute(context));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(c.getTime());
    }

    public static void scheduleReminder(Context context) {
        if (!hasReminder(context)) return;

        int hour = getReminderHour(context);
        int minute = getReminderMinute(context);

        Calendar now = Calendar.getInstance();
        Calendar trigger = Calendar.getInstance();
        trigger.set(Calendar.HOUR_OF_DAY, hour);
        trigger.set(Calendar.MINUTE, minute);
        trigger.set(Calendar.SECOND, 0);
        trigger.set(Calendar.MILLISECOND, 0);

        if (!trigger.after(now)) {
            trigger.add(Calendar.DAY_OF_YEAR, 1);
        }

        Intent intent = new Intent(context, ReminderReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                2001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    trigger.getTimeInMillis(),
                    AlarmManager.INTERVAL_DAY,
                    pendingIntent
            );
        }
    }
}
