package com.example.quran.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "reading_sessions")
public class ReadingSession {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String day;        // yyyy-MM-dd
    public String surahName;  // Al-Fatiha for now
    public int readCount;     // number of ayat read
    public long timestamp;

    public ReadingSession(String day, String surahName, int readCount, long timestamp) {
        this.day = day;
        this.surahName = surahName;
        this.readCount = readCount;
        this.timestamp = timestamp;
    }
}
