package com.example.quran;

import android.Manifest;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.quran.data.AppDatabase;
import com.example.quran.data.DailyTotal;
import com.example.quran.data.ReadingSession;
import com.example.quran.data.Surah;
import com.example.quran.data.SurahRepository;
import com.example.quran.notify.NotificationHelper;
import com.example.quran.notify.ReminderScheduler;
import com.example.quran.view.ReadingChartView;
import com.example.quran.util.DateUtils;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_NOTIF = 101;

    private AppDatabase db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private Spinner spinnerSurah;
    private EditText etAyat;
    private TextView tvToday;
    private TextView tvSelectedSurah;
    private TextView tvReminderTime;
    private ReadingChartView chartView;

    private List<Surah> surahList;
    private Surah selectedSurah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(this);
        NotificationHelper.createChannel(this);
        requestNotificationPermissionIfNeeded();

        spinnerSurah = findViewById(R.id.spinnerSurah);
        etAyat = findViewById(R.id.etAyat);
        tvToday = findViewById(R.id.tvToday);
        tvSelectedSurah = findViewById(R.id.tvSelectedSurah);
        tvReminderTime = findViewById(R.id.tvReminderTime);
        chartView = findViewById(R.id.chartView);

        Button btnRead = findViewById(R.id.btnRead);
        Button btnTestReminder = findViewById(R.id.btnTestReminder);
        Button btnSetReminder = findViewById(R.id.btnSetReminder);

        setupSurahSpinner();
        if (ReminderScheduler.hasReminder(this)) {
            ReminderScheduler.scheduleReminder(this);
        }
        refreshReminderLabel();

        btnRead.setOnClickListener(v -> saveReadingSession());
        btnTestReminder.setOnClickListener(v -> {
            String name = selectedSurah != null ? selectedSurah.name : ReminderScheduler.getReminderSurah(this);
            NotificationHelper.showReminder(this, name);
        });
        btnSetReminder.setOnClickListener(v -> openTimePicker());

        loadStats();
    }

    private void setupSurahSpinner() {
        surahList = SurahRepository.getAllSurahs();

        ArrayAdapter<Surah> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                surahList
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSurah.setAdapter(adapter);

        selectedSurah = surahList.get(0);
        tvSelectedSurah.setText("Selected surah: " + selectedSurah.name + " (" + selectedSurah.ayatCount + " ayat)");
        ReminderScheduler.updateSurah(this, selectedSurah.name);

        spinnerSurah.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSurah = surahList.get(position);
                tvSelectedSurah.setText("Selected surah: " + selectedSurah.name + " (" + selectedSurah.ayatCount + " ayat)");
                ReminderScheduler.updateSurah(MainActivity.this, selectedSurah.name);
                refreshReminderLabel();
                loadStats();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void refreshReminderLabel() {
        String time = ReminderScheduler.getReminderLabel(this);
        String surah = ReminderScheduler.getReminderSurah(this);
        tvReminderTime.setText("Reminder: " + time + " • " + surah);
    }

    private void openTimePicker() {
        Calendar calendar = Calendar.getInstance();
        TimePickerDialog dialog = new TimePickerDialog(
                this,
                (TimePicker view, int hourOfDay, int minute) -> {
                    String surahName = selectedSurah != null ? selectedSurah.name : ReminderScheduler.getReminderSurah(this);
                    ReminderScheduler.saveReminder(this, hourOfDay, minute, surahName);
                    ReminderScheduler.scheduleReminder(this);
                    refreshReminderLabel();
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                true
        );
        dialog.show();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_NOTIF
                );
            }
        }
    }

    private void saveReadingSession() {
        Surah surah = selectedSurah;
        if (surah == null) return;

        int ayatCount = 1;
        String input = etAyat.getText().toString().trim();

        if (!input.isEmpty()) {
            try {
                ayatCount = Integer.parseInt(input);
            } catch (NumberFormatException ignored) {
                ayatCount = 1;
            }
        }

        if (ayatCount < 1) ayatCount = 1;
        if (ayatCount > surah.ayatCount) ayatCount = surah.ayatCount;

        final int finalAyatCount = ayatCount;

        executor.execute(() -> {
            String day = DateUtils.todayString();
            ReadingSession session = new ReadingSession(
                    day,
                    surah.name,
                    finalAyatCount,
                    System.currentTimeMillis()
            );

            db.readingSessionDao().insert(session);
            loadStats();
        });
    }

    private void loadStats() {
        Surah surah = selectedSurah;
        if (surah == null) return;

        executor.execute(() -> {
            String today = DateUtils.todayString();
            int todayTotal = db.readingSessionDao().getTotalForDayAndSurah(today, surah.name);
            List<DailyTotal> totals = db.readingSessionDao().getDailyTotalsForSurah(surah.name);

            runOnUiThread(() -> {
                tvToday.setText("Today: " + todayTotal + " ayat from " + surah.name);
                chartView.setData(totals);
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshReminderLabel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
